from chalice import Chalice
from packages import geoip
import os
app = Chalice(app_name='geoip')
app.debug = True

@app.route('/')
def index():
    return {'hello': 'world'}

@app.route('/where_am_i')
def return_requst():
   try:
      return geoip.geolite2.lookup(app.current_request.to_dict()['context']['source-ip'])
   except: 
      with  geoip.open_database("./packages/GeoLite2-City.mmdb") as db:
         return str(db.lookup(app.current_request.to_dict()['context']['source-ip']))
      
@app.route('/fs')
def show_fs():
   return [f for f in os.walk('.')]
